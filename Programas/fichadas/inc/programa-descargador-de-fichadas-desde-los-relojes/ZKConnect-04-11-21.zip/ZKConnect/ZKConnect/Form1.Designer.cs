﻿namespace ZKConnect
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.button1 = new System.Windows.Forms.Button();
            this.PrgSTA = new System.Windows.Forms.ProgressBar();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.lbSysOutputInfo = new System.Windows.Forms.ListBox();
            this.checkBox_timePeriod = new System.Windows.Forms.CheckBox();
            this.btn_readnewlog = new System.Windows.Forms.Button();
            this.btn_readAttLog = new System.Windows.Forms.Button();
            this.stime_log = new System.Windows.Forms.DateTimePicker();
            this.label15 = new System.Windows.Forms.Label();
            this.etime_log = new System.Windows.Forms.DateTimePicker();
            this.label16 = new System.Windows.Forms.Label();
            this.gv_Attlog = new System.Windows.Forms.DataGridView();
            this.ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Date = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.VType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.VState = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Workcode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.gv_Attlog)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(12, 493);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "conectar";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // PrgSTA
            // 
            this.PrgSTA.Location = new System.Drawing.Point(194, 477);
            this.PrgSTA.Name = "PrgSTA";
            this.PrgSTA.Size = new System.Drawing.Size(660, 21);
            this.PrgSTA.TabIndex = 86;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(3, 467);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 88;
            // 
            // lbSysOutputInfo
            // 
            this.lbSysOutputInfo.FormattingEnabled = true;
            this.lbSysOutputInfo.Location = new System.Drawing.Point(3, 376);
            this.lbSysOutputInfo.Name = "lbSysOutputInfo";
            this.lbSysOutputInfo.Size = new System.Drawing.Size(851, 95);
            this.lbSysOutputInfo.TabIndex = 89;
            // 
            // checkBox_timePeriod
            // 
            this.checkBox_timePeriod.AutoSize = true;
            this.checkBox_timePeriod.Location = new System.Drawing.Point(14, 11);
            this.checkBox_timePeriod.Name = "checkBox_timePeriod";
            this.checkBox_timePeriod.Size = new System.Drawing.Size(82, 17);
            this.checkBox_timePeriod.TabIndex = 114;
            this.checkBox_timePeriod.Text = "Time Period";
            this.checkBox_timePeriod.UseVisualStyleBackColor = true;
            // 
            // btn_readnewlog
            // 
            this.btn_readnewlog.Location = new System.Drawing.Point(34, 220);
            this.btn_readnewlog.Name = "btn_readnewlog";
            this.btn_readnewlog.Size = new System.Drawing.Size(154, 23);
            this.btn_readnewlog.TabIndex = 113;
            this.btn_readnewlog.Text = "ReadNewAttLogData";
            this.btn_readnewlog.UseVisualStyleBackColor = true;
            this.btn_readnewlog.Click += new System.EventHandler(this.btn_readnewlog_Click_1);
            // 
            // btn_readAttLog
            // 
            this.btn_readAttLog.Location = new System.Drawing.Point(34, 136);
            this.btn_readAttLog.Name = "btn_readAttLog";
            this.btn_readAttLog.Size = new System.Drawing.Size(154, 23);
            this.btn_readAttLog.TabIndex = 112;
            this.btn_readAttLog.Text = "ReadAttLog";
            this.btn_readAttLog.UseVisualStyleBackColor = true;
            this.btn_readAttLog.Click += new System.EventHandler(this.btn_readAttLog_Click_1);
            // 
            // stime_log
            // 
            this.stime_log.CustomFormat = "yyyy-MM-dd HH:mm:ss";
            this.stime_log.Enabled = false;
            this.stime_log.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.stime_log.Location = new System.Drawing.Point(37, 34);
            this.stime_log.Name = "stime_log";
            this.stime_log.Size = new System.Drawing.Size(151, 20);
            this.stime_log.TabIndex = 110;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(0, 37);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(30, 13);
            this.label15.TabIndex = 108;
            this.label15.Text = "From";
            // 
            // etime_log
            // 
            this.etime_log.CustomFormat = "yyyy-MM-dd HH:mm:ss";
            this.etime_log.Enabled = false;
            this.etime_log.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.etime_log.Location = new System.Drawing.Point(37, 64);
            this.etime_log.Name = "etime_log";
            this.etime_log.Size = new System.Drawing.Size(151, 20);
            this.etime_log.TabIndex = 111;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(10, 68);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(20, 13);
            this.label16.TabIndex = 109;
            this.label16.Text = "To";
            // 
            // gv_Attlog
            // 
            this.gv_Attlog.AllowUserToAddRows = false;
            this.gv_Attlog.AllowUserToOrderColumns = true;
            this.gv_Attlog.AllowUserToResizeRows = false;
            this.gv_Attlog.BackgroundColor = System.Drawing.SystemColors.Window;
            this.gv_Attlog.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.gv_Attlog.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gv_Attlog.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ID,
            this.Date,
            this.VType,
            this.VState,
            this.Workcode});
            this.gv_Attlog.Location = new System.Drawing.Point(203, 2);
            this.gv_Attlog.MultiSelect = false;
            this.gv_Attlog.Name = "gv_Attlog";
            this.gv_Attlog.ReadOnly = true;
            this.gv_Attlog.RowHeadersWidth = 20;
            this.gv_Attlog.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.gv_Attlog.RowTemplate.Height = 23;
            this.gv_Attlog.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gv_Attlog.Size = new System.Drawing.Size(660, 359);
            this.gv_Attlog.TabIndex = 107;
            // 
            // ID
            // 
            this.ID.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.ID.DataPropertyName = "ID";
            this.ID.FillWeight = 80F;
            this.ID.HeaderText = "User ID";
            this.ID.Name = "ID";
            this.ID.ReadOnly = true;
            // 
            // Date
            // 
            this.Date.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.Date.DataPropertyName = "Date";
            this.Date.HeaderText = "Verify Date";
            this.Date.Name = "Date";
            this.Date.ReadOnly = true;
            // 
            // VType
            // 
            this.VType.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.VType.DataPropertyName = "VType";
            this.VType.FillWeight = 80F;
            this.VType.HeaderText = "Verify Type";
            this.VType.Name = "VType";
            this.VType.ReadOnly = true;
            // 
            // VState
            // 
            this.VState.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.VState.DataPropertyName = "VState";
            this.VState.FillWeight = 80F;
            this.VState.HeaderText = "Verify State";
            this.VState.Name = "VState";
            this.VState.ReadOnly = true;
            // 
            // Workcode
            // 
            this.Workcode.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.Workcode.DataPropertyName = "Workcode";
            this.Workcode.FillWeight = 80F;
            this.Workcode.HeaderText = "WorkCode";
            this.Workcode.Name = "Workcode";
            this.Workcode.ReadOnly = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(34, 249);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(154, 23);
            this.button2.TabIndex = 115;
            this.button2.Text = "Save";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(779, 504);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 116;
            this.button3.Text = "button3";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // timer1
            // 
            this.timer1.Interval = 300000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(972, 528);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.checkBox_timePeriod);
            this.Controls.Add(this.btn_readnewlog);
            this.Controls.Add(this.btn_readAttLog);
            this.Controls.Add(this.stime_log);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.etime_log);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.gv_Attlog);
            this.Controls.Add(this.lbSysOutputInfo);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.PrgSTA);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.gv_Attlog)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ProgressBar PrgSTA;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.ListBox lbSysOutputInfo;
        private System.Windows.Forms.CheckBox checkBox_timePeriod;
        private System.Windows.Forms.Button btn_readnewlog;
        private System.Windows.Forms.Button btn_readAttLog;
        private System.Windows.Forms.DateTimePicker stime_log;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.DateTimePicker etime_log;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.DataGridView gv_Attlog;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn Date;
        private System.Windows.Forms.DataGridViewTextBoxColumn VType;
        private System.Windows.Forms.DataGridViewTextBoxColumn VState;
        private System.Windows.Forms.DataGridViewTextBoxColumn Workcode;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Timer timer1;
    }
}

