﻿using StandaloneSDKDemo;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


using System.Data.OleDb;

namespace ZKConnect
{
    public partial class Form1 : Form
    {
        public StandaloneSDKDemo.SDKHelper SDK = new SDKHelper();
        public Form1()
        {
            InitializeComponent();
        }

        private void leer()
        {
            Cursor = Cursors.WaitCursor;
            //'5010'
            //4370
            OleDbConnection nwindConn = new OleDbConnection("Provider=SQLOLEDB;Data Source=192.168.122.17;Initial Catalog=Fichadas;User Id=SA;Password=Fu11@c3$*9739");
            OleDbCommand catCMD = nwindConn.CreateCommand();
            nwindConn.Open();
            OleDbCommand catCMD2 = nwindConn.CreateCommand();

           timer1.Stop();
            bool descargarSiempreTodo;
            descargarSiempreTodo = true;
            //catCMD.CommandText = " select DireccionIP,Puerto,Clave,Codigo,Dependencia from relojes where Codigo=51 order by Codigo asc ";
            catCMD.CommandText = " select DireccionIP,Puerto,Clave,Codigo,Dependencia from relojes where Codigo=51  order by Codigo asc ";
            //catCMD.ExecuteNonQuery();
            string wCodigo;
            System.Data.OleDb.OleDbDataReader dr;
            dr = catCMD.ExecuteReader();
            while (dr.Read())
            {
                int value = SDK.sta_ConnectTCP(lbSysOutputInfo, dr.GetString(0).Trim(), dr.GetString(1).Trim(), dr.GetString(2).Trim());
                //int value = SDK.sta_ConnectTCP(lbSysOutputInfo, "192.168.122.232","5010","0");
                if (SDK.GetConnectState())
                {
                    SDK.sta_getBiometricType();
                }
                if (value == 1) //conexion exitosa
                {
                    if (dr.GetInt32(3) == 51 || descargarSiempreTodo)
                    {
                        //************************************************************************************
                        // DESCARGA TODO:
                        DataTable dt_period = new DataTable("dt_period");
                        gv_Attlog.AutoGenerateColumns = true;
                        gv_Attlog.Columns.Clear();
                        dt_period.Columns.Add("User ID", System.Type.GetType("System.String"));
                        dt_period.Columns.Add("Verify Date", System.Type.GetType("System.String"));
                        dt_period.Columns.Add("Verify Type", System.Type.GetType("System.Int32"));
                        dt_period.Columns.Add("Verify State", System.Type.GetType("System.Int32"));
                        dt_period.Columns.Add("WorkCode", System.Type.GetType("System.Int32"));
                        gv_Attlog.DataSource = dt_period;
                        SDK.sta_readAttLog(lbSysOutputInfo, dt_period);
                    }
                    else
                    {
                        //***********************************************************************************
                        // DESCARGA SOLO LO NUEVO:
                        DataTable dt_newLog = new DataTable("dt_periodLog");
                        gv_Attlog.AutoGenerateColumns = true;
                        gv_Attlog.Columns.Clear();
                        dt_newLog.Columns.Add("User ID", System.Type.GetType("System.String"));
                        dt_newLog.Columns.Add("Verify Date", System.Type.GetType("System.String"));
                        dt_newLog.Columns.Add("Verify Type", System.Type.GetType("System.Int32"));
                        dt_newLog.Columns.Add("Verify State", System.Type.GetType("System.Int32"));
                        dt_newLog.Columns.Add("WorkCode", System.Type.GetType("System.Int32"));
                        gv_Attlog.DataSource = dt_newLog;
                        Cursor = Cursors.WaitCursor;
                        SDK.sta_ReadNewAttLog(lbSysOutputInfo, dt_newLog);
                        Cursor = Cursors.Default;
                    }
                    //OleDbConnection nwindConn2 = new OleDbConnection("Provider=SQLOLEDB;Data Source=192.168.122.17;Initial Catalog=Fichadas;User Id=SA;Password=Fu11@c3$*9739");
                    //nwindConn.Open();
                    // idReloj,fecha,ip,dependencia,cantFichadas
                    catCMD2.CommandText = " insert into captura(idReloj,fecha,ip,cantFichadas) values(" + dr.GetInt32(3) + ",'" + DateTime.Now.ToString("yyyy-MM-dd") + "','" + dr.GetString(0).Trim() + "',0)";
                    catCMD2.ExecuteNonQuery();
                    double wid;
                    wid = 0;
                    catCMD2.CommandText = "Select max(id) from captura";
                    System.Data.OleDb.OleDbDataReader dr2;
                    dr2 = catCMD2.ExecuteReader();
                    if (dr2.Read())
                    {
                        wid = dr2.GetInt32(0);
                    }
                    dr2.Close();

                    double cantFichadas;
                    cantFichadas = 0;
                    try
                    {
                        
                        for (int fila = 0; fila < gv_Attlog.Rows.Count - 1; fila++)
                        {
                            string idEmpleado = gv_Attlog.Rows[fila].Cells[0].Value.ToString(); //'idEmpleado'
                            string fecha = gv_Attlog.Rows[fila].Cells[1].Value.ToString();
                            string tipoEvento = gv_Attlog.Rows[fila].Cells[3].Value.ToString();
                            if (idEmpleado != "" && fecha != "" && tipoEvento != "")
                            {
                                catCMD2.CommandText = " select * from fichadas_x_captura where idEmpleado="+ idEmpleado + " and fecha='"+fecha+"'";
                                dr2 = catCMD2.ExecuteReader();
                                if (dr2.Read())
                                {
                                    dr2.Close();
                                }
                                else
                                {
                                    dr2.Close();
                                    catCMD2.CommandText = " insert into fichadas_x_captura(idEmpleado,fecha,tipo,idCaptura) values(" + idEmpleado + ",'" + fecha + "'," + tipoEvento + "," + wid + ")";
                                    catCMD2.ExecuteNonQuery();
                                    cantFichadas = cantFichadas + 1;
                                }

                                
                            }
                            // myReader.Close();
                        }
                    }
                    catch(Exception e)
                    {
                        System.IO.StreamWriter sw = new System.IO.StreamWriter(Application.StartupPath + "/Test.txt", true);
                        //Write a line of 
                        sw.WriteLine(DateTime.Now + " Error insertar fila en SQL. ID Reloj: " + dr.GetInt32(3) + "Error: " + e.Message + " Consulta SQL: " + catCMD2.CommandText);
                        sw.WriteLine("");
                        sw.Close();
                    }

                    

                    catCMD2.CommandText = " update captura set cantFichadas=" + cantFichadas + " where id=" + wid;
                    catCMD2.ExecuteNonQuery();
                    SDK.sta_DisConnect();
                    SDK.SetConnectState(false);
                    //nwindConn.Close();
                }
                else if (value == -2) //conexion fallida
                {
                    //NO SE PUDO CONECTAR AL RELOJ
                    //lbSysOutputInfo
                    insert_log_error(dr.GetString(0).Trim() + " Descripcion error: value == -2) //conexion fallida", dr.GetString(1).Trim(), dr.GetInt32(3), catCMD2);

                }
                else if (value!=1)
                {
                    insert_log_error(dr.GetString(0).Trim() + " Descripcion error: " + lbSysOutputInfo.Items[lbSysOutputInfo.Items.Count - 1].ToString(), dr.GetString(1).Trim(), dr.GetInt32(3), catCMD2);
                }
            }

            //System.Windows.Forms.Application.Exit(); //cierra 

            timer1.Interval = 2800000;
            timer1.Start();


            //for (int fila = 0; fila < gv_Attlog.Rows.Count - 1; fila++)
            //{
            //    string idEmpleado = gv_Attlog.Rows[fila].Cells[0].Value.ToString(); //'idEmpleado'
            //    string fecha = gv_Attlog.Rows[fila].Cells[1].Value.ToString();
            //    string tipoEvento = gv_Attlog.Rows[fila].Cells[3].Value.ToString();
            //    if (idEmpleado != "" && fecha != "" && tipoEvento != "")
            //    {
            //        catCMD.CommandText = " insert into fichadas_x_captura(idEmpleado,fecha,tipo,idCaptura) values(" + idEmpleado + ",'" + fecha + "'," + tipoEvento + ",1)";
            //        catCMD.ExecuteNonQuery();
            //    }
            //}
            //nwindConn.Close();


            //int value = SDK.sta_ConnectTCP(lbSysOutputInfo , "10.178.2.40", "5010", "7777");
            ////int value = SDK.sta_ConnectTCP(lbSysOutputInfo, "192.168.144.40", "5010", "7777"); 
            //if (SDK.GetConnectState())
            //{
            //    SDK.sta_getBiometricType();
            //}
            //if (value == 1) //conexion exitosa
            //{
            //    //SDK.sta_GetDeviceInfo(Terminal.lbSysOutputInfo, out sFirmver, out sMac, out sPlatform, out sSN, out sProductTime, out sDeviceName, out iFPAlg, out iFaceAlg, out sProducter);
            //    //txtFirmwareVer.Text = sFirmver;
            //    //txtMac.Text = sMac;
            //    //txtSerialNumber.Text = sSN;
            //    //txtPlatForm.Text = sPlatform;
            //    //txtDeviceName.Text = sDeviceName;
            //    //txtFPAlg.Text = iFPAlg.ToString().Trim();
            //    //txtFaceAlg.Text = iFaceAlg.ToString().Trim();
            //    //txtManufacturer.Text = sProducter;
            //    //txtManufactureTime.Text = sProductTime;
            //}
            //else if (value == -2) //conexion fallida
            //{

            //}
            Cursor = Cursors.Default;

            
        }
        private void button1_Click(object sender, EventArgs e)
        {
            leer();
            //MessageBox.Show("OK");
        }

        private void insert_log_error(String ip, String puerto, int id_reloj, OleDbCommand cmd)
        {
            cmd.CommandText = "insert into log_error_captura(descripcion,reloj,fecha) values('Error al conectar con ip: " + ip  + "',"+ id_reloj +",'"  + DateTime.Now.ToString("yyyy-MM-dd")  + "') ";
            cmd.ExecuteNonQuery();
            cmd.CommandText = "update relojes set fecha_ultimo_error='" + DateTime.Now.ToString("yyyy-MM-dd HH:mm") + "' , descripcion_ultimo_error='"+ ip + "' where Codigo="+ id_reloj;
            cmd.ExecuteNonQuery();
        }

     

        private void checkBox_timePeriod_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void btn_readnewlog_Click(object sender, EventArgs e)
        {

        }

        private void btn_deloldlog_Click(object sender, EventArgs e)
        {

        }

        private void btn_delAttLog_Click(object sender, EventArgs e)
        {

        }

        private void btn_readAttLog_Click(object sender, EventArgs e)
        {

        }

        private void btn_readAttLog_Click_1(object sender, EventArgs e)
        {
            Cursor = Cursors.WaitCursor;
            if (checkBox_timePeriod.Checked == true)
            {
                string fromTime = stime_log.Text.Trim().ToString();
                string toTime = etime_log.Text.Trim().ToString();

                DataTable dt_periodLog = new DataTable("dt_periodLog");
                gv_Attlog.AutoGenerateColumns = true;
                gv_Attlog.Columns.Clear();
                dt_periodLog.Columns.Add("User ID", System.Type.GetType("System.String"));
                dt_periodLog.Columns.Add("Verify Date", System.Type.GetType("System.String"));
                dt_periodLog.Columns.Add("Verify Type", System.Type.GetType("System.Int32"));
                dt_periodLog.Columns.Add("Verify State", System.Type.GetType("System.Int32"));
                dt_periodLog.Columns.Add("WorkCode", System.Type.GetType("System.Int32"));
                gv_Attlog.DataSource = dt_periodLog;

                SDK.sta_readLogByPeriod(lbSysOutputInfo, dt_periodLog, fromTime, toTime);
            }
            else
            {
                DataTable dt_period = new DataTable("dt_period");
                gv_Attlog.AutoGenerateColumns = true;
                gv_Attlog.Columns.Clear();
                dt_period.Columns.Add("User ID", System.Type.GetType("System.String"));
                dt_period.Columns.Add("Verify Date", System.Type.GetType("System.String"));
                dt_period.Columns.Add("Verify Type", System.Type.GetType("System.Int32"));
                dt_period.Columns.Add("Verify State", System.Type.GetType("System.Int32"));
                dt_period.Columns.Add("WorkCode", System.Type.GetType("System.Int32"));
                gv_Attlog.DataSource = dt_period;

                SDK.sta_readAttLog(lbSysOutputInfo, dt_period);
            }
            Cursor = Cursors.Default;
        }

        private void btn_readnewlog_Click_1(object sender, EventArgs e)
        {
            DataTable dt_newLog = new DataTable("dt_periodLog");
            gv_Attlog.AutoGenerateColumns = true;
            gv_Attlog.Columns.Clear();
            dt_newLog.Columns.Add("User ID", System.Type.GetType("System.String"));
            dt_newLog.Columns.Add("Verify Date", System.Type.GetType("System.String"));
            dt_newLog.Columns.Add("Verify Type", System.Type.GetType("System.Int32"));
            dt_newLog.Columns.Add("Verify State", System.Type.GetType("System.Int32"));
            dt_newLog.Columns.Add("WorkCode", System.Type.GetType("System.Int32"));
            gv_Attlog.DataSource = dt_newLog;

            Cursor = Cursors.WaitCursor;
            SDK.sta_ReadNewAttLog(lbSysOutputInfo, dt_newLog);
            Cursor = Cursors.Default;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            OleDbConnection nwindConn = new OleDbConnection("Provider=SQLOLEDB;Data Source=192.168.122.17;Initial Catalog=Fichadas;User Id=SA;Password=Fu11@c3$*9739");
            OleDbCommand catCMD = nwindConn.CreateCommand();
            nwindConn.Open();
            // idReloj,fecha,ip,dependencia,cantFichadas
            catCMD.CommandText = " insert into captura(idReloj,fecha,ip,dependencia,cantFichadas) values(" + 1 + ",'" + DateTime.Now + "','" + "192.168.0.1" + "','HNCK',0)";
            catCMD.ExecuteNonQuery();

            for (int fila = 0; fila < gv_Attlog.Rows.Count - 1; fila++)
            {
                string idEmpleado = gv_Attlog.Rows[fila].Cells[0].Value.ToString(); //'idEmpleado'
                string fecha = gv_Attlog.Rows[fila].Cells[1].Value.ToString();
                string tipoEvento = gv_Attlog.Rows[fila].Cells[3].Value.ToString();
                if(idEmpleado!="" && fecha !="" && tipoEvento != "")
                {
                    catCMD.CommandText = " insert into fichadas_x_captura(idEmpleado,fecha,tipo,idCaptura) values(" + idEmpleado + ",'" + fecha + "'," + tipoEvento + ",1)";
                    catCMD.ExecuteNonQuery();
                }
                
               // myReader.Close();
            }
            nwindConn.Close();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            int value = SDK.sta_ConnectTCP(lbSysOutputInfo, "10.178.2.40", "5010", "0");
            if (SDK.GetConnectState())
            {
                SDK.sta_getBiometricType();
            }
            MessageBox.Show(value.ToString());
            SDK.SetConnectState(false);
            SDK.sta_DisConnect();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
            //'1.800.000' milisegundos = 30 minutos


            System.IO.StreamWriter sw = new System.IO.StreamWriter( Application.StartupPath  + "/Test.txt",true);
            //Write a line of 
            sw.WriteLine("");
            sw.WriteLine(DateTime.Now + " Form Load");
            sw.WriteLine("");
            sw.Close();

            //leer();

            timer1.Interval = 2800000;
            timer1.Start();

            

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            leer();
        }
    }
}
